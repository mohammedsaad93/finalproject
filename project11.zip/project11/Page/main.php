<h1 class="title">Wellcome</h1>
<h2 class="title" align="center">Main Page</h2>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque dignissimos error excepturi inventore molestiae similique voluptas. Aliquid aperiam aspernatur dolorum facere mollitia pariatur, placeat quibusdam, quidem quis repellat similique, suscipit?
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi asperiores, corporis dicta dignissimos doloremque est fugiat id illum iusto maiores maxime nesciunt pariatur perspiciatis, quaerat repudiandae sunt tempore vel veniam.
<br><br><br><br><br>
<html>
    <head>
        <link href="../admin/css/style.css" rel="stylesheet">
    </head>
    <body>

        <div class="gallery">
            <a target="_blank" href="img_gallery/img.jpg">
                <img src="img_gallery/img.jpg" alt="Trolltunga Norway" width="300" height="200">
            </a>
            <div class="desc">description of the image</div>
        </div>

        <div class="gallery">
            <a target="_blank" href="img_gallery/img.jpg">
                <img src="img_gallery/img.jpg" alt="Trolltunga Norway" width="300" height="200">
            </a>
            <div class="desc">description of the image</div>
        </div>

        <div class="gallery">
            <a target="_blank" href="img_gallery/img.jpg">
                <img src="img_gallery/img.jpg" alt="Trolltunga Norway" width="300" height="200">
            </a>
            <div class="desc">description of the image</div>
        </div>

        <div class="gallery">
            <a target="_blank" href="img_gallery/img.jpg">
                <img src="img_gallery/img.jpg" alt="Trolltunga Norway" width="300" height="200">
            </a>
            <div class="desc">description of the image</div>
        </div>

        <div class="gallery">
            <a target="_blank" href="img_gallery/img.jpg">
                <img src="img_gallery/img.jpg" alt="Trolltunga Norway" width="300" height="200">
            </a>
            <div class="desc">description of the image</div>
        </div>

        <div class="gallery">
            <a target="_blank" href="img_gallery/img.jpg">
                <img src="img_gallery/img.jpg" alt="Trolltunga Norway" width="300" height="200">
            </a>
            <div class="desc">description of the image</div>
        </div>

        <?php
            require '../admin/connect.php';//connction
            $sql = "SELECT * FROM blog2 ORDER BY id DESC";
            $result = mysqli_query($con,$sql);
            $data = [];
            while ($row = mysqli_fetch_assoc($result)):
                $data[] = $row;
            endwhile;
        ?>

        <table>
            <tr>
                <th>Title</th>
                <th>Post</th>
                <th>section</th>
            </tr>
            <?php foreach ($data as $item): ?>
                <tr>
                    <td><?= $item['title'] ?></td>
                    <td><?= $item['post'] ?></td>
                    <td><?=$item['section'] ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </body>
</html>

<p id="legal">Copyright &copy; 2007 Pure n' Simple. All Rights Reserved. Designed by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
<p id="links"><a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>



