<html>
    <head>
      <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <?php require 'connect.php' //connction?>

        <?php $id = $_GET['id'];
            $sql = "SELECT * FROM blog2 WHERE id ='$id'";
            $result = mysqli_query($con, $sql);
            $data = [];
            while ($row = mysqli_fetch_assoc($result)):
                $data[] = $row;
            endwhile;
        ?>
        <?php foreach ($data as $item): ?>
            <form action="post/delete_post.php?id=<?= $id ?>" method="post">
                <br><br><br><br><br>
                <h1>Are You Sure To Delete This Blog ?</h1>
                <h2><?= $item['title'] ?></h2>
                <h2><?= $item['post'] ?></h2>
                <h2><?= $item['section'] ?></h2>
                <button type="submit" value="Delete" class="button">Delete</button><br>
                <a href="main.php" class="button">Back to Blog</a>
            </form>
        <?php endforeach; ?>
    </body>
</html>


