<?php require 'connect.php'; //connction?>
<html>
    <head>
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <h1 class="title">Blog Page</h1>
        <a href="add.php" class="button">Add Blog</a>
        <?php $sql = "SELECT * FROM blog2 ORDER BY id DESC";
            $result = mysqli_query($con,$sql);
            $data = [];
            while ($row = mysqli_fetch_assoc($result)):
                $data[] = $row;
            endwhile;
        ?>
        <table>
            <tr>
                <th>Title</th>
                <th>Post</th>
                <th>section</th>
                <th>Action</th>
            </tr>
            <?php foreach ($data as $item): ?>
                <tr>
                    <td><?= $item['title'] ?></td>
                    <td><?= $item['post'] ?></td>
                    <td><?=$item['section'] ?></td>
                    <td>
                        <a class="button" href="update.php?id=<?= $item['id'] ?>">Update</a><br>
                        <a class="button" href="delete.php?id=<?= $item['id'] ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <br><br><br><br><br>
        <a href="post/loguot_post.php" class="button">Logout</a>
    </body>
</html>
