<?php
     $con = mysqli_connect('localhost', 'root', 'root', 'FSDB');//connect on database
?>