<?php
    require '../connect.php';//connction
    $id = $_GET['id'];
    $sql = "DELETE FROM blog2 WHERE id = '$id'";
    if (mysqli_query($con,$sql))
        header('location:../main.php');
    else
        echo 'ERROR!!';
?>