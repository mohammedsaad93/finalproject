<?php
require '../connect.php';

$id = $_GET['id'];
$title = $_POST['title'];
$post = $_POST['post'];
$section=$_POST['section'];

$sql = "UPDATE blog2 SET title = '$title' , post = '$post' ,Section='$section' WHERE id = '$id'";

if (mysqli_query($con,$sql))
    header('location:../main.php');
else
    echo 'ERROR!!';