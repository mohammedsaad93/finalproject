<?php
    require '../connect.php'; //connction;
    session_start();
    $email=$_POST["email"];
    $username=$_POST["username"];
    $password=$_POST["password"];
    $sql="SELECT email, username, password FROM login WHERE email='$email' and username='$username' and password='$password' ";
    $result = mysqli_query($con,$sql);
    if (!$row=mysqli_fetch_assoc($result))
    {
        header('location:login.php');
    }
    else {
        $_SESSION[login]="good";
        header('location:../main.php');
    }
    mysqli_close($con);
?>
