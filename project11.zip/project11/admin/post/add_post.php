<?php
require '../connect.php';

$title = $_POST['title'];
$post = $_POST['post'];
$section = $_POST['section'];

$sql = "INSERT INTO blog2 (title,post,section) VALUES ('$title','$post','$section')";

if (mysqli_query($con,$sql))
    header('location:../main.php');
else
    echo 'ERROR!!';