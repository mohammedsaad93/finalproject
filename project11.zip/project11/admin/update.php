<html>
<head>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
<?php require 'connect.php' //connction?>
<br><br><br>
<h1 class="title">Update Blog</h1>
<br><br><br>
<?php $id = $_GET['id'];
    $sql = "SELECT * FROM blog2 WHERE id ='$id'";
    $result = mysqli_query($con, $sql);
    $data = [];
    while ($row = mysqli_fetch_assoc($result)):
        $data[] = $row;
    endwhile;
?>
<?php foreach ($data as $item): ?>
    <form action="post/update_post.php?id=<?= $id ?>" method="post">
        <input type="text" value="<?= $item['title'] ?>" name="title">
        <br>
        <input type="text" value="<?= $item['post'] ?>" name="post"  >
        <br>
        <input type="text" value="<?=$item['section']?>" name="section">
        <br>
        <button type="submit" value="Update" class="button">Update</button>
    </form>
<?php endforeach; ?>
</body>
</html>

