<html>
    <head>
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <br><br><br>
        <h1 class="title">Update Blog</h1>
        <form action="post/add_post.php" method="post">
            <input type="text" placeholder="add title" name="title" >
            <br>
            <input type="text" placeholder="add post" name="post" >
            <br>
            <input type="text" placeholder="add section" name="section">
            <br>
            <button type="submit" value="Add" class="button">Add</button><br>
        </form>
    </body>
</html>


