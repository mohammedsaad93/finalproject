<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <br><br><br><br><br>
        <h1>Wellcome</h1>
        <br><br><br>
        <form  action="post/login_post.php" method="post">
            <input  type="text" name="email" placeholder="Enter Email"><br>
            <input  type="text" name="username" placeholder="Enter Username"><br>
            <input type="password" name="password" placeholder="Enter Password"><br>
            <button type="submit" value="Login" class="button">Login</button>
        </form>
    </body>
</html>